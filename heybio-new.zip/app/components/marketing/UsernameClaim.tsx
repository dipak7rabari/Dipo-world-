
import { useId, useState } from "react";
import type { FormEvent } from "react";
import { ArrowUpRight, Sparkles } from "lucide-react";
import "../../styles/surprise-cta.css";
import { useNavigate } from "react-router";

/**
 * HEYBIO by DIPO LABS
 *
 * Homepage username claim component.
 *
 * Rules:
 * - No backend availability requests.
 * - CTA remains enabled.
 * - CTA text updates while typing.
 * - Username is only a temporary preference.
 * - Authentication happens before onboarding.
 * - Username ownership is verified later.
 */

const STORAGE_KEY = "heybio:desired-username";

const MAX_INPUT_LENGTH = 100;

export default function UsernameClaim() {
  const navigate = useNavigate();

  const inputId = useId();
  const feedbackId = useId();

  const [username, setUsername] = useState("");
  const [storageError, setStorageError] =
    useState("");

  // Display preference only, not a verified username.
  const requestedUsername = username
    .trim()
    .toLowerCase();

  // Dynamic call-to-action.
  const buttonText = requestedUsername
    ? `Continue with @${requestedUsername}`
    : "Claim my HEYBIO";

  function handleUsernameChange(value: string) {
    setUsername(value.slice(0, MAX_INPUT_LENGTH));

    if (storageError) {
      setStorageError("");
    }
  }

  function handleSubmit(
    event: FormEvent<HTMLFormElement>,
  ) {
    event.preventDefault();
    setStorageError("");

    // Do not perform username availability
    // checks on the homepage.

    try {
      if (requestedUsername) {
        window.localStorage.setItem(
          STORAGE_KEY,
          requestedUsername,
        );
      } else {
        window.localStorage.removeItem(
          STORAGE_KEY,
        );
      }
    } catch {
      setStorageError(
        "We couldn't save your username in this browser. Please enable site storage and try again.",
      );

      return;
    }

    // Existing/new creator handling belongs
    // to verified authentication and onboarding.
    navigate("/signup");
  }

  return (
    <form
      className="hx-claim"
      onSubmit={handleSubmit}
      noValidate
    >
      <label
        className="hx-claim__label"
        htmlFor={inputId}
      >
        Claim your own corner of the internet
      </label>

      <div className="hx-claim__row">
        <div className="hx-claim__input-wrap">
          <span
            className="hx-claim__prefix"
            aria-hidden="true"
          >
            heybio.in/
          </span>

          <input
            id={inputId}
            type="text"
            name="username"
            value={username}
            onChange={(event) =>
              handleUsernameChange(
                event.currentTarget.value,
              )
            }
            placeholder="yourname"
            maxLength={MAX_INPUT_LENGTH}
            inputMode="text"
            autoComplete="off"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            aria-describedby={feedbackId}
          />
        </div>

        <button
          className="hx-claim__button"
          type="submit"
        >
          <span
            key={buttonText}
            className="hx-claim__button-text"
          >
            {buttonText}
          </span>

          <ArrowUpRight
            size={18}
            aria-hidden="true"
            style={{ flexShrink: 0 }}
          />
        </button>
      </div>

      <p
        id={feedbackId}
        role={storageError ? "alert" : "status"}
        aria-live="polite"
        className="hx-claim__feedback"
      >
        {storageError ||
          "Continue now. We'll check your username during setup."}
      </p>

      <a
        href="/bio"
        className="hx-surprise-cta"
        aria-label="Surprise for Creators — Explore free bio symbols"
      >
        <span className="hx-surprise-cta__spark" aria-hidden="true">
          <Sparkles size={15} strokeWidth={2} />
        </span>
        <span className="hx-surprise-cta__label">Surprise for Creators</span>
        <ArrowUpRight
          size={15}
          strokeWidth={2}
          aria-hidden="true"
          className="hx-surprise-cta__arrow"
        />
      </a>
    </form>
  );
}
