import symbolsHtml from "../../data/bio-symbols.html?raw";

/**
 * Public standalone resource route.
 * Returns the original DIPO BIO HTML directly at https://heybio.in/bio.
 * Keeps all existing HEYBIO layouts, routes, auth and styling isolated.
 */
export function loader() {
  return new Response(symbolsHtml, {
    status: 200,
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
