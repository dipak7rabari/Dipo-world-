HEYBIO — Surprise for Creators | /bio | DIPO BIO Symbols Lab
===========================================================

IMPORTANT: This ZIP is a SMALL SAFE OVERLAY for your EXISTING HEYBIO
project, NOT a new full website. Unzip it INSIDE the latest project root.
It adds one blue homepage CTA and one new standalone /bio page only.

1. In VS Code terminal, go to your current HEYBIO project root
   (folder containing package.json, app/, wrangler.jsonc).
2. Backup any newer local changes to the two replaced source files:
   app/routes.ts
   app/components/marketing/UsernameClaim.tsx
3. Place heybio-new.zip inside that project root.
4. Run exactly:
   unzip -o heybio-new.zip
   npm run build
   npx wrangler deploy

Then verify:
  https://heybio.in/        => animated blue 'Surprise for Creators' under CTA
  https://heybio.in/bio     => full original dark DIPO BIO Symbols Lab

ONLY files affected:
  app/routes.ts                                  (adds /bio route)
  app/components/marketing/UsernameClaim.tsx   (adds blue CTA)
  app/styles/surprise-cta.css                   (scoped new CTA animations)
  app/routes/marketing/bio.ts                   (standalone /bio HTML resource route)
  app/data/bio-symbols.html                     (original DIPO BIO page + symbols)

No changes to login/signup, dashboard, payments, subscriptions, Supabase,
Cloudflare bindings, SEO files, creator public pages or other homepage sections.

Symbols: 2,635 unique items across 22 categories; original DIPO BIO items
and layout remain in original order. iPhone/Android glyph shapes can differ,
and no platform-exclusive emoji look can be guaranteed. Most additions are
Unicode text symbols rather than colorful emoji.

Original Symbols Lab retains its CSS/layout/animations and copy behavior.
Only '← Bio Tools' link has been removed. The /bio page is directly served
as standalone HTML rather than inside an iframe to avoid CSS/scroll conflicts.

NOTE: Do not unzip a full outdated HEYBIO source ZIP over your live work.
This ZIP contains only the 5 files listed above. If your local app/routes.ts
or UsernameClaim.tsx differ from the 21 Oct 2026 source archive, review those
two replacements before deploying; don't overwrite newer authentication work.
